package com.aiops.aiops_engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiopsEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
