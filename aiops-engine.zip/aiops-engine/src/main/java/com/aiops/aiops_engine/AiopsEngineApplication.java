package com.aiops.aiops_engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiopsEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiopsEngineApplication.class, args);
	}

}
